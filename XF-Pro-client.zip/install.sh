#!/system/bin/sh
# XF-Pro 安装/启动脚本
# 用法：MT 里以 root 执行

DIR=$(dirname "$0")
CARD_FILE="/data/adb/xfpro/card.txt"

echo "================================"
echo "        XF-Pro 启动器"
echo "================================"

if [ "$(id -u)" != "0" ]; then
  echo "! 请用 root 执行（MT 里长按 → 以 root 运行）"
  exit 1
fi

# 1. 准备 curl
if [ ! -x /data/local/tmp/curl ]; then
  if [ -x "$DIR/curl" ]; then
    cp "$DIR/curl" /data/local/tmp/curl
    chmod 755 /data/local/tmp/curl
  else
    echo "! 缺少 curl，请把 MT 的 curl 复制到 /data/local/tmp/curl"
    echo "  cp /data/user/0/bin.mt.plus.canary/files/term/bin/curl /data/local/tmp/curl"
    exit 1
  fi
fi

# 2. 卡密
if [ -f "$CARD_FILE" ]; then
  CARD=$(cat "$CARD_FILE")
  echo "- 使用已保存卡密"
else
  printf "请输入卡密: "
  read CARD
  [ -z "$CARD" ] && echo "! 卡密不能为空" && exit 1
fi

# 3. 加载 TwT 驱动
if ! lsmod 2>/dev/null | grep -qi twt; then
  if [ -f "$DIR/TwTLoaderv1.56.sh" ]; then
    echo "- 加载 TwT 驱动..."
    sh "$DIR/TwTLoaderv1.56.sh" >/dev/null 2>&1
  else
    echo "! 未找到 TwTLoaderv1.56.sh"
  fi
fi

# 4. 启动客户端
echo "- 启动客户端..."
chmod 755 "$DIR/shadowd"
"$DIR/shadowd" "$CARD" "com.tencent.mf.uam"

# 5. 验证成功才保存卡密
if [ $? -eq 0 ]; then
  mkdir -p /data/adb/xfpro
  echo "$CARD" > "$CARD_FILE"
  echo "✓ 卡密已保存"
fi
